# Plixer Website

A responsive dark-themed landing page concept for a college project.

## Run it
1. Extract `plixer_website.zip`.
2. Open `index.html` in any modern browser.

No build tools, libraries, or internet connection are required.

## Included interactions
- Responsive mobile navigation
- Dark/light theme toggle
- Scroll reveal animations (respects reduced-motion preferences)
- Project showcase with beginner-friendly project roadmap
- Active navigation state while scrolling
- Responsive dashboard illustration
- Smooth scrolling and lightweight toast feedback

This is a front-end college project/demo. Login, cloud sync, real accounts, and backend services are not connected.

## Portfolio project notes
The project cards distinguish the current Plixer website from suggested next projects. The Student Task Tracker, Student Grade Calculator, and Number Guessing Game are learning ideas, not claims that those apps have already been completed.
